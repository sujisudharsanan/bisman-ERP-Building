# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e3]:
    - generic [ref=e7]:
      - heading "Sign in" [level=1] [ref=e8]
      - paragraph [ref=e9]: Use your account
    - generic [ref=e11]:
      - generic [ref=e12]:
        - generic [ref=e13]:
          - generic [ref=e14]: Email or phone
          - textbox "Email or phone" [ref=e15]
        - generic [ref=e16]:
          - generic [ref=e17]: Password
          - generic [ref=e18]:
            - textbox "Password" [ref=e19]
            - button [ref=e20] [cursor=pointer]:
              - img [ref=e21]
        - generic [ref=e24]:
          - button "Forgot email?" [ref=e26] [cursor=pointer]
          - button "Next" [disabled] [ref=e28]:
            - generic [ref=e29]: Next
      - generic [ref=e31]:
        - heading "Demo accounts" [level=3] [ref=e32]
        - button "Show" [ref=e33] [cursor=pointer]
      - generic [ref=e34]: Not your computer? Use Private Browsing windows to sign in. Learn more about using Guest mode
  - alert [ref=e35]
```